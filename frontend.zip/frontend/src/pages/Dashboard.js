import React, { useState } from 'react';
export const Dashboard = () => {
  return <h1>hellodssssssssssssssssssssssssssssssssssssssssssssssssss</h1>;
};
export default Dashboard;
